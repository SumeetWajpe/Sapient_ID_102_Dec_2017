var Square = function (x) {
  return x * x;
};
console.log(Square(10));
