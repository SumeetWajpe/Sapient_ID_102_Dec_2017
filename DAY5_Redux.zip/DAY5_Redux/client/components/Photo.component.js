import React from 'react';

class Photo extends React.Component{
    render(){
        return <div>
                        <h2>Photo Component</h2>
                    </div>
    }
}

export default Photo;