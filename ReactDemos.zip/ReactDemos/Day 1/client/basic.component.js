
import React  from 'react';  // corrspnd to react folder in node_modules
export class BasicComponent extends React.Component{
    render(){
        return <h1> React using Webpack ! </h1>
    }
}